set schema 'enfants';
select init();

begin transaction; --t1

SELECT classe
FROM enfant WHERE nopers = 1 ; --t3

SELECT classe
FROM enfant WHERE nopers = 1; --t5

SELECT classe
FROM enfant WHERE nopers = 1;  --t7

commit; --t8

SELECT classe FROM enfant WHERE nopers = 1;  --t9
